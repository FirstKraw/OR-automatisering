"""Lokaal maaltijdenbeheer voor Oranje."""
